README:
-------

Development server: Use ‘ng serve’ for a dev server.
----------------------------------------------------

Use ‘ng generate compoment component-name’ to create a new component.
---------------------------------------------------------------------

Build: To build use ‘ng build’ this will build the project.
-----------------------------------------------------------

Tests: To start tests use ‘ng test’.
-------------------------------------

End to end tests: To run end to end tests use ‘ng e2e’. 
-------------------------------------------------------
