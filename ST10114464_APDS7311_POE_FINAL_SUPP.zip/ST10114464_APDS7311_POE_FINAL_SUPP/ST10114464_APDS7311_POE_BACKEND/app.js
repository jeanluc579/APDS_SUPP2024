require('dotenv').config();
const express = require('express')
const app = express()
const https = require('https');
const mongoose = require("mongoose")
const fs = require('fs')
const helmet = require('helmet')
const cors = require('cors')
const hsts = require('./middleware/hsts')
const morgan = require('morgan');

mongoose.connect(process.env.mongoDBurl).then(() => console.log('DB Connected...'));

// Middleware
app.use(cors({ origin: 'http://localhost:4200', optionsSuccessStatus: 200 }));
app.use(express.json());
app.use(hsts);

//Helmet middleware used to secure site 
app.use(helmet());
//Uses helmet middleware to help prevent clickjacking Uses 
app.use(
    helmet({
        frameguard: {
            action: "deny",
        },
    })
);

//Morgan middleware to log HTTP requests in the combined format
app.use(morgan('combined'));

// Routes
app.use('/api/users', require('./routes/user'))
app.use('/api/posts', require('./routes/posts'))

app.use((reg, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.setHeader('Access-Control-Allow-Methods', '*');
    next();
});

https.createServer(
    {
        key: fs.readFileSync('./keys/privatekey.pem'),
        cert: fs.readFileSync('./keys/certificate.pem'),
        passphrase: 'apds',
    },
    app
).listen(3000)

module.exports = app;